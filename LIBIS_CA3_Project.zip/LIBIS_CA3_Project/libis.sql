-- LIBIS assessment database. Safe to re-run: drops and recreates the schema.
-- Run this script as a MySQL administrator (for example, root).

DROP SCHEMA IF EXISTS libis;
CREATE SCHEMA libis CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE libis;

CREATE TABLE members (
    member_id INT NOT NULL AUTO_INCREMENT,
    member_number VARCHAR(30) NOT NULL,
    full_name VARCHAR(150) NOT NULL,
    email VARCHAR(190) NOT NULL,
    username VARCHAR(80) NOT NULL,
    password VARCHAR(255) NOT NULL,
    `role` VARCHAR(20) NOT NULL DEFAULT 'member',
    PRIMARY KEY (member_id),
    UNIQUE KEY uq_members_member_number (member_number),
    UNIQUE KEY uq_members_email (email),
    UNIQUE KEY uq_members_username (username),
    CONSTRAINT chk_members_role CHECK (`role` IN ('member', 'librarian'))
) ENGINE=InnoDB;

CREATE TABLE books (
    book_id INT NOT NULL AUTO_INCREMENT,
    isbn VARCHAR(20) NOT NULL,
    title VARCHAR(200) NOT NULL,
    author VARCHAR(160) NOT NULL,
    published_year SMALLINT NOT NULL,
    genre VARCHAR(100) NOT NULL DEFAULT '',
    synopsis TEXT,
    PRIMARY KEY (book_id),
    UNIQUE KEY uq_books_isbn (isbn)
) ENGINE=InnoDB;

CREATE TABLE loans (
    loan_id INT NOT NULL AUTO_INCREMENT,
    member_id INT NOT NULL,
    book_id INT NOT NULL,
    borrowed_on DATE NOT NULL,
    returned_on DATE NULL,
    PRIMARY KEY (loan_id),
    KEY ix_loans_member_open (member_id, returned_on),
    KEY ix_loans_book_open (book_id, returned_on),
    CONSTRAINT fk_loans_member FOREIGN KEY (member_id) REFERENCES members(member_id) ON DELETE CASCADE,
    CONSTRAINT fk_loans_book FOREIGN KEY (book_id) REFERENCES books(book_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Preserve the five original CA1/CA2 sample members. Login usernames remain their email addresses.
INSERT INTO members (member_id, member_number, full_name, email, username, password, `role`) VALUES
(1, 'LIB-001', 'Johanson Sebudi', 'johanson@gmail.com', 'johanson@gmail.com', 'passJ1', 'member'),
(2, 'LIB-002', 'Karabo Moitse', 'karabo@gmail.com', 'karabo@gmail.com', 'passK2', 'member'),
(3, 'LIB-003', 'Pako Daniels', 'pako@gmail.com', 'pako@gmail.com', 'passP3', 'member'),
(4, 'LIB-004', 'Tumelo Mokgosi', 'tumelo@gmail.com', 'tumelo@gmail.com', 'passT4', 'member'),
(5, 'LIB-005', 'Tefo Mogorosi', 'tefo@gmail.com', 'tefo@gmail.com', 'passT5', 'member'),
(6, 'LIB-ADM-001', 'LIBIS System Librarian', 'librarian@libis.local', 'librarian@libis.local', 'LibisAdmin2026!', 'librarian');

-- Original ten CA1/CA2 books, with ISBN and publication year added for this assessment.
INSERT INTO books (book_id, isbn, title, author, published_year, genre, synopsis) VALUES
(1, '9780132350884', 'Clean Code', 'Robert C. Martin', 2008, 'Programming', 'Practical advice for writing readable, maintainable code.'),
(2, '9780134685991', 'Effective Java', 'Joshua Bloch', 2018, 'Programming', 'Best practices and patterns for writing solid Java code.'),
(3, '9780596009205', 'Head First Java', 'Kathy Sierra', 2005, 'Programming', 'A visual introduction to Java fundamentals.'),
(4, '9780135957059', 'The Pragmatic Programmer', 'Andrew Hunt', 2019, 'Programming', 'Timeless tips for becoming a more effective developer.'),
(5, '9781260463415', 'Java: The Complete Reference', 'Herbert Schildt', 2020, 'Programming', 'A comprehensive reference for Java language features.'),
(6, '9780201633610', 'Design Patterns', 'Erich Gamma', 1994, 'Software Design', 'Classic solutions to common object-oriented design problems.'),
(7, '9780201485677', 'Refactoring', 'Martin Fowler', 1999, 'Software Design', 'Techniques for improving code structure without changing behavior.'),
(8, '9780262046305', 'Introduction to Algorithms', 'Thomas H. Cormen', 2022, 'Algorithms', 'A deep guide to algorithms and data structures.'),
(9, '9780073523323', 'Database System Concepts', 'Abraham Silberschatz', 2010, 'Databases', 'Core database concepts, modeling, and query fundamentals.'),
(10, '9781449331818', 'Learning Web App Development', 'Semmy Purewal', 2014, 'Web Development', 'Hands-on introduction to building modern web applications.');

-- Nine loans: LIB-001 holds three open books (limit test); LIB-002 has both open and returned loans (cascade test).
INSERT INTO loans (loan_id, member_id, book_id, borrowed_on, returned_on) VALUES
(1, 1, 1, CURRENT_DATE - INTERVAL 18 DAY, NULL),
(2, 1, 2, CURRENT_DATE - INTERVAL 12 DAY, NULL),
(3, 1, 3, CURRENT_DATE - INTERVAL 8 DAY, NULL),
(4, 2, 4, CURRENT_DATE - INTERVAL 7 DAY, NULL),
(5, 2, 5, CURRENT_DATE - INTERVAL 45 DAY, CURRENT_DATE - INTERVAL 31 DAY),
(6, 2, 6, CURRENT_DATE - INTERVAL 35 DAY, CURRENT_DATE - INTERVAL 22 DAY),
(7, 3, 7, CURRENT_DATE - INTERVAL 28 DAY, CURRENT_DATE - INTERVAL 15 DAY),
(8, 4, 8, CURRENT_DATE - INTERVAL 5 DAY, NULL),
(9, 5, 9, CURRENT_DATE - INTERVAL 60 DAY, CURRENT_DATE - INTERVAL 49 DAY);

-- Development login used by META-INF/context.xml. Restrict or change this for a real deployment.
CREATE USER IF NOT EXISTS 'libis_app'@'localhost' IDENTIFIED BY 'LibisDev2026!';
ALTER USER 'libis_app'@'localhost' IDENTIFIED BY 'LibisDev2026!';
GRANT SELECT, INSERT, UPDATE, DELETE, REFERENCES ON libis.* TO 'libis_app'@'localhost';
FLUSH PRIVILEGES;
