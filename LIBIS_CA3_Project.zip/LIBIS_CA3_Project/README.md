# LIBIS - Database, Security, Loans and Internationalisation Assessment

This is the extended Maven project based on the supplied CA2 LIBIS application. It replaces the in-memory lists and custom authentication filter with MySQL persistence and Tomcat-managed FORM authentication, and adds librarian management, member loans, and English/Setswana catalogue pages.

## Included functionality

- **MySQL persistence:** `members`, `books`, and `loans` tables; JDBC DAOs use `PreparedStatement`, try-with-resources, and application-level logging.
- **Tomcat authentication:** `DataSourceRealm` authenticates from `members`; container security constraints protect member and librarian routes. The old `AuthenticationFilter` is not present or mapped.
- **Librarian management:** member and book list/search/create/edit/delete flows, duplicate checks, validation, confirmation pages, and POST/Redirect/GET after successful changes.
- **Loan management:** borrow, return, current loans, returned-loan history, and the three-book limit in `LoanService`.
- **Internationalisation:** catalogue and My Loans use UTF-8 `messages.properties` and `messages_tn.properties` bundles, with the selected language stored in session scope.
- **Protected views:** only `login.jsp` and `login-error.jsp` are outside `WEB-INF`; other JSPs are reached through controllers.

## Requirements

- JDK 21
- Apache Maven 3.9.16 or later (the Maven Wrapper is included)
- Apache Tomcat 11.x (Jakarta Servlet 6.1)
- MySQL 8.4 LTS recommended

## 1. Create and seed the database

> **Important:** `libis.sql` intentionally starts with `DROP SCHEMA IF EXISTS libis`. It deletes and recreates an existing database named `libis`. Run it only in your local assessment environment after confirming that the schema contains no data you need to keep.

From the project root, run the script as a MySQL administrator:

```bash
mysql -u root -p < libis.sql
```

The script creates the schema and tables, adds the original five members and ten books from the supplied CA2 `LibraryData`, adds a librarian, inserts nine sample loans, and creates the application database account used by the Tomcat context. It can be rerun because it recreates the schema and uses `CREATE USER IF NOT EXISTS` followed by `ALTER USER`.

The default database connection values in `src/main/webapp/META-INF/context.xml` are:

| Setting | Value |
|---|---|
| Database | `libis` |
| JDBC URL | `jdbc:mysql://localhost:3306/libis` |
| Database user | `libis_app` |
| Database password | `LibisDev2026!` |
| JNDI name | `java:comp/env/jdbc/libis` |

For a different local MySQL port, host, or password, update both the SQL script and `META-INF/context.xml` so they agree. The supplied database account is for local assessment/testing only; change it before any non-classroom deployment.

## 2. Install MySQL Connector/J for Tomcat

The Maven dependency is declared with `provided` scope because the Tomcat `DataSourceRealm` and container-managed pool need the driver in Tomcat's common classloader. After Maven has resolved dependencies, copy this JAR into Tomcat's `lib` directory:

```text
~/.m2/repository/com/mysql/mysql-connector-j/26.10.0/mysql-connector-j-26.10.0.jar
```

Destination:

```text
$CATALINA_BASE/lib/
```

If `CATALINA_BASE` is not set separately, use `$CATALINA_HOME/lib/`. Restart Tomcat after adding the driver. The project uses MySQL Connector/J 26.10.0, the current GA release at the time this project was prepared. The release is recommended by MySQL and targets current MySQL Server releases. See the official [Connector/J 26.10.0 release notes](https://dev.mysql.com/doc/relnotes/connector-j/en/news-26-10-0.html).

## 3. Build the Maven WAR

macOS/Linux:

```bash
chmod +x mvnw
./mvnw clean package
```

Windows PowerShell:

```powershell
.\mvnw.cmd clean package
```

Expected output:

```text
target/LIBIC-LoginFlow-1.0-SNAPSHOT.war
```

The WAR does not include the Servlet API or MySQL Connector/J; Tomcat supplies the Servlet API and the Connector/J JAR is installed in Tomcat's `lib` directory as described above. JSTL libraries are packaged with the application.

## 4. Deploy to Tomcat 11

1. Ensure MySQL is running and the `libis` schema has been seeded.
2. Confirm the Connector/J JAR is in Tomcat's `lib` directory and restart Tomcat.
3. Copy `target/LIBIC-LoginFlow-1.0-SNAPSHOT.war` into Tomcat's `webapps` directory.
4. Start or restart Tomcat and open:

   `http://localhost:8080/LIBIC-LoginFlow-1.0-SNAPSHOT/`

   The welcome file is `/catalogue`, so opening the application root triggers container authentication and then lands on the catalogue. After signing in, the container returns the user to the originally requested protected resource.

`META-INF/context.xml` declares the JNDI DataSource and a `DataSourceRealm` using that same DataSource. Because the Realm is nested in the application Context, `localDataSource="true"` tells Tomcat to use the Context-local resource. See the [Tomcat 11 Realm configuration reference](https://tomcat.apache.org/tomcat-11.0-doc/realm-howto.html) and the [DataSourceRealm configuration attributes](https://tomcat.apache.org/tomcat-11.0-doc/config/realm.html#DataSource_Realm_-_org.apache.catalina.realm.DataSourceRealm).

## 5. Seeded test logins

All usernames below are the login values to enter in the `Username` field. Passwords are plain text for this assessment seed only.

| Role | Member number | Username | Password | Initial loan state |
|---|---|---|---|---|
| Member | `LIB-001` | `johanson@gmail.com` | `passJ1` | Three open loans (loan-limit test) |
| Member | `LIB-002` | `karabo@gmail.com` | `passK2` | One open and two returned loans (cascade-delete test) |
| Member | `LIB-003` | `pako@gmail.com` | `passP3` | One returned loan |
| Member | `LIB-004` | `tumelo@gmail.com` | `passT4` | One open loan |
| Member | `LIB-005` | `tefo@gmail.com` | `passT5` | One returned loan |
| Librarian | `LIB-ADM-001` | `librarian@libis.local` | `LibisAdmin2026!` | No loans |

## 6. Important seeded examples

- `LIB-001` (Johanson Sebudi) holds the first three books. Attempt to borrow an available book while signed in as this member to see the maximum-three-loans rejection.
- `LIB-002` (Karabo Moitse) has an open loan for *The Pragmatic Programmer* and returned loans for *Java: The Complete Reference* and *Design Patterns*. This member is the recommended account for the cascade-delete demonstration. Before deleting the member, record the matching rows in `loans`; after deletion, the member's entire loan history should be gone and *The Pragmatic Programmer* should become available.
- Use `LIB-005` (Tefo Mogorosi) to demonstrate a successful borrow and return without first changing the three-open-loan example.

## 7. Application routes and access control

| Route | Access | Purpose |
|---|---|---|
| `/catalogue` | `member`, `librarian` | Browse/search catalogue |
| `/loans` | `member` | My Loans (current loans and returned history) |
| `/loans/borrow` (POST) | `member` | Borrow a book |
| `/loans/return` (POST) | `member` | Return a book |
| `/librarian/members` | `librarian` | Search/list members |
| `/librarian/members/new` (GET), `/create` (POST) | `librarian` | Add a member |
| `/librarian/members/edit` (GET), `/update` (POST) | `librarian` | Edit a member |
| `/librarian/members/delete` (GET confirmation, POST deletion) | `librarian` | Delete a member |
| `/librarian/books` | `librarian` | Search/list books |
| `/librarian/books/new` (GET), `/create` (POST) | `librarian` | Add a book |
| `/librarian/books/edit` (GET), `/update` (POST) | `librarian` | Edit a book |
| `/librarian/books/delete` (GET confirmation, POST deletion) | `librarian` | Delete a book |
| `/logout` (POST in the views) | `member`, `librarian` | Container logout and session invalidation |

Security is enforced by the `security-constraint` elements in `WEB-INF/web.xml`; hiding a menu link is not used as the access-control mechanism. A member requesting a `/librarian/*` route directly should receive HTTP 403 from Tomcat.

## 8. Package structure

```text
com.example.libicloginflow
  config       DataSourceProvider (JNDI lookup)
  controller   Catalogue, loans, member management, book management, logout
  dao          MemberDao, BookDao, LoanDao interfaces
  dao.impl     JDBC implementations
  exception    DataAccessException, ValidationException, LoanException
  filter       CharacterEncodingFilter only (no authentication filter)
  model        Member, Book, Loan
  service      MemberService, BookService, LoanService
```

`Member` keeps the legacy constructor and `getName()`, `setName()`, `getLastname()`, and `setLastname()` methods while adding `memberNumber`, `fullName`, `username`, and `role`. `Book` keeps its original constructor and properties while adding `isbn` and `publishedYear`; `available` is still a model property but is calculated by `BookDaoJdbc` from the absence of an open loan. `Loan` is new and represents a single row in the `loans` table.

## 9. Manual verification checklist

Run these checks against the local Tomcat/MySQL deployment and capture your own screenshots for the evidence document.

1. Sign in as a member and a librarian. Confirm both can open `/catalogue`; confirm the librarian sees member/book management links and the member sees My Loans.
2. As a member, type `/librarian/members` directly in the address bar. Confirm Tomcat returns HTTP 403.
3. As the librarian, search members by part of a name and by member number. Create, edit, and delete a test member. Try duplicate member number, email, and username values and confirm field-level messages appear without a SQL stack trace. Confirm a librarian cannot delete their own account.
4. As the librarian, search books by title and author. Create and edit a test book. Try a duplicate ISBN, `20x4` as a year, and a future publication year; confirm form-level errors and retained inputs. Confirm an open-loan book cannot be deleted. Delete a test book with only returned loan history and confirm its past loan rows cascade away.
5. As `LIB-001`, attempt to borrow an available book. Confirm the three-book maximum message appears. As `LIB-005`, borrow an available book, verify the catalogue availability changes, return the book, and verify it moves to borrowing history with both dates.
6. Open My Loans and confirm current loans, returned history, and the number of the three allowed loans in use.
7. Switch the catalogue to Setswana, open My Loans, and confirm the language remains Setswana. Switch back to English and verify that also persists.
8. As the librarian, delete `LIB-002` after taking a screenshot of their rows in `loans`. In MySQL, verify all of that member's loan rows have been deleted and the previously open book is now available. Capture the loans table before and after deletion.
9. Log out, press Back, and verify that protected content is not shown; requesting a protected URL should require authentication again.

Useful cascade evidence queries:

```sql
-- BEFORE deleting LIB-002: expect 3 rows (one open, two returned).
SELECT l.loan_id, m.member_number, b.title, l.borrowed_on, l.returned_on
FROM loans l
JOIN members m ON m.member_id = l.member_id
JOIN books b ON b.book_id = l.book_id
WHERE m.member_number = 'LIB-002'
ORDER BY l.loan_id;

-- AFTER deleting LIB-002: expect 0 rows.
SELECT COUNT(*) AS remaining_loans
FROM loans l
JOIN members m ON m.member_id = l.member_id
WHERE m.member_number = 'LIB-002';

-- The Pragmatic Programmer (book_id 4) should now be available (1).
SELECT b.title,
       NOT EXISTS (
           SELECT 1 FROM loans l
           WHERE l.book_id = b.book_id AND l.returned_on IS NULL
       ) AS available
FROM books b
WHERE b.book_id = 4;
```

## 10. Evidence and build status

`LIBIS_Evidence_Document_Template.pdf` is included as a captioned evidence template. It lists the test logins, model changes, screenshot slots, and the SQL checks for the cascade demonstration. It does **not** contain fabricated application screenshots: this workspace did not have a running Tomcat/MySQL instance. Complete each screenshot slot using your actual local deployment before submission.

The uploaded materials did not include the lecturer's Section 11.1 screenshot rubric or Appendix 1 cover sheet. The evidence template therefore covers the checks inferable from the supplied Sections 2-10; attach the official Appendix 1 cover sheet and make the required AI declaration using your lecturer's form.

A source-level Java compilation check and XML parsing checks passed in the preparation environment. A full Maven build, MySQL execution, JSP compilation, and live Tomcat/browser verification could not be completed here because Maven Central DNS resolution was unavailable and no MySQL/Tomcat service was installed. Run the Maven Wrapper and the manual verification checklist above in your local environment before submission.
