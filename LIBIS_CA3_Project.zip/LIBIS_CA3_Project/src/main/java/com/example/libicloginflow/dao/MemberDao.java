package com.example.libicloginflow.dao;

import com.example.libicloginflow.model.Member;
import java.util.List;

public interface MemberDao {
    List<Member> findAll();
    Member findById(int id);
    Member findByUsername(String username);
    List<Member> search(String term);
    Member findByMemberNumber(String memberNumber);
    Member findByEmail(String email);
    Member findByUsernameExact(String username);
    int create(Member member);
    void update(Member member);
    void delete(int id);
}
