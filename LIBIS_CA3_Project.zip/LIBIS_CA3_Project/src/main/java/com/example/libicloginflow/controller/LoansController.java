package com.example.libicloginflow.controller;

import com.example.libicloginflow.dao.BookDao;
import com.example.libicloginflow.dao.LoanDao;
import com.example.libicloginflow.dao.MemberDao;
import com.example.libicloginflow.dao.impl.BookDaoJdbc;
import com.example.libicloginflow.dao.impl.LoanDaoJdbc;
import com.example.libicloginflow.dao.impl.MemberDaoJdbc;
import com.example.libicloginflow.exception.DataAccessException;
import com.example.libicloginflow.exception.LoanException;
import com.example.libicloginflow.model.Member;
import com.example.libicloginflow.service.LoanService;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.List;

/** Member loan actions. Member identity always comes from the container Principal. */
public class LoansController extends HttpServlet {
    private final BookDao bookDao = new BookDaoJdbc();
    private final LoanDao loanDao = new LoanDaoJdbc();
    private final MemberDao memberDao = new MemberDaoJdbc();
    private final LoanService loanService = new LoanService(bookDao, loanDao);

    @Override protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            showLoans(request, response);
        } catch (DataAccessException ex) {
            forwardLoansError(request, response, null);
        }
    }

    @Override protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String action = request.getPathInfo();
        Member member = null;
        int bookId = safeId(request.getParameter("bookId"));
        try {
            member = signedInMember(request);
            if (member == null) {
                response.sendError(HttpServletResponse.SC_FORBIDDEN);
                return;
            }
            if ("/borrow".equals(action)) {
                loanService.borrow(member.getMemberId(), bookId);
                response.sendRedirect(request.getContextPath() + "/catalogue");
            } else if ("/return".equals(action)) {
                loanService.returnBook(member.getMemberId(), bookId);
                request.getSession().setAttribute("libisLoanFlashKey", "loans.returnSuccess");
                response.sendRedirect(request.getContextPath() + "/loans");
            } else {
                response.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
            }
        } catch (LoanException ex) {
            request.setAttribute("loanError", ex.getMessage());
            if ("/borrow".equals(action)) {
                showCatalogue(request, response, member);
            } else {
                try {
                    showLoans(request, response);
                } catch (DataAccessException dataError) {
                    forwardLoansError(request, response, member);
                }
            }
        } catch (DataAccessException ex) {
            if ("/borrow".equals(action)) forwardCatalogueError(request, response, member);
            else forwardLoansError(request, response, member);
        }
    }

    private void showLoans(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Member member = signedInMember(request);
        if (member == null) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        request.setAttribute("member", member);
        request.setAttribute("openLoans", loanDao.findOpenByMember(member.getMemberId()));
        request.setAttribute("historyLoans", loanDao.findHistoryByMember(member.getMemberId()));
        request.setAttribute("currentLoanCount", loanService.countOpenByMember(member.getMemberId()));
        request.setAttribute("maxLoans", LoanService.MAX_LOANS);
        Object flashKey = request.getSession().getAttribute("libisLoanFlashKey");
        if (flashKey != null) {
            request.setAttribute("successMessageKey", flashKey);
            request.getSession().removeAttribute("libisLoanFlashKey");
        }
        request.getRequestDispatcher("/WEB-INF/views/my-loans.jsp").forward(request, response);
    }

    private void showCatalogue(HttpServletRequest request, HttpServletResponse response, Member member) throws ServletException, IOException {
        try {
            String q = request.getParameter("q");
            List<?> books = q == null || q.isBlank() ? bookDao.findAll() : bookDao.search(q.trim());
            request.setAttribute("books", books);
            request.setAttribute("searchTerm", q == null ? "" : q.trim());
            request.setAttribute("totalBooks", books.size());
            request.setAttribute("member", member);
            request.setAttribute("isLibrarian", request.isUserInRole("librarian"));
            request.setAttribute("isMember", request.isUserInRole("member"));
        } catch (DataAccessException ex) {
            setCatalogueErrorAttributes(request, member);
        }
        request.getRequestDispatcher("/WEB-INF/views/welcome.jsp").forward(request, response);
    }

    private void forwardCatalogueError(HttpServletRequest request, HttpServletResponse response, Member member) throws ServletException, IOException {
        setCatalogueErrorAttributes(request, member);
        request.getRequestDispatcher("/WEB-INF/views/welcome.jsp").forward(request, response);
    }

    private void setCatalogueErrorAttributes(HttpServletRequest request, Member member) {
        request.setAttribute("pageError", Boolean.TRUE);
        request.setAttribute("books", List.of());
        request.setAttribute("searchTerm", request.getParameter("q") == null ? "" : request.getParameter("q"));
        request.setAttribute("totalBooks", 0);
        request.setAttribute("member", member);
        request.setAttribute("isLibrarian", request.isUserInRole("librarian"));
        request.setAttribute("isMember", request.isUserInRole("member"));
    }

    private void forwardLoansError(HttpServletRequest request, HttpServletResponse response, Member member) throws ServletException, IOException {
        request.setAttribute("pageError", Boolean.TRUE);
        request.setAttribute("member", member);
        request.setAttribute("openLoans", List.of());
        request.setAttribute("historyLoans", List.of());
        request.setAttribute("currentLoanCount", 0);
        request.setAttribute("maxLoans", LoanService.MAX_LOANS);
        request.getRequestDispatcher("/WEB-INF/views/my-loans.jsp").forward(request, response);
    }

    private Member signedInMember(HttpServletRequest request) {
        String username = request.getRemoteUser();
        return username == null ? null : memberDao.findByUsername(username);
    }

    private int safeId(String value) {
        try { return Integer.parseInt(value); }
        catch (RuntimeException ex) { return -1; }
    }
}
