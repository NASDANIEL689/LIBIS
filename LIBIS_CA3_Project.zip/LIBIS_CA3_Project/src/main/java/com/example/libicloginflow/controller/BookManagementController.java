package com.example.libicloginflow.controller;

import com.example.libicloginflow.dao.BookDao;
import com.example.libicloginflow.dao.impl.BookDaoJdbc;
import com.example.libicloginflow.dao.impl.LoanDaoJdbc;
import com.example.libicloginflow.exception.DataAccessException;
import com.example.libicloginflow.exception.ValidationException;
import com.example.libicloginflow.model.Book;
import com.example.libicloginflow.service.BookService;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.Map;

public class BookManagementController extends HttpServlet {
    private final BookDao bookDao = new BookDaoJdbc();
    private final BookService bookService = new BookService(bookDao, new LoanDaoJdbc());

    @Override protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String path = path(request);
        try {
            switch (path) {
                case "/new" -> showForm(request, response, new Book(), "Add book", "create", null);
                case "/edit" -> {
                    Book book = bookService.findById(parseId(request.getParameter("id")));
                    if (book == null) { flash(request, "The selected book could not be found."); redirectList(request, response); return; }
                    showForm(request, response, book, "Edit book", "update", String.valueOf(book.getPublishedYear()));
                }
                case "/delete" -> {
                    Book book = bookService.findById(parseId(request.getParameter("id")));
                    if (book == null) { flash(request, "The selected book could not be found."); redirectList(request, response); return; }
                    request.setAttribute("book", book);
                    request.getRequestDispatcher("/WEB-INF/views/books/book-delete.jsp").forward(request, response);
                }
                default -> list(request, response);
            }
        } catch (IllegalArgumentException ex) { flash(request, "The requested book ID is invalid."); redirectList(request, response); }
        catch (DataAccessException ex) { flash(request, "Book records could not be loaded. Please check the database connection."); redirectList(request, response); }
    }

    @Override protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String path = path(request);
        try {
            switch (path) {
                case "/create" -> {
                    Book book = bind(request, 0);
                    try { bookService.create(book); flash(request, "Book " + book.getTitle() + " has been added."); redirectList(request, response); }
                    catch (ValidationException ex) { showFormErrors(request, response, book, "Add book", "create", ex, request.getParameter("publishedYear")); }
                }
                case "/update" -> {
                    Book book = bind(request, safeId(request.getParameter("bookId")));
                    try { bookService.update(book); flash(request, "Book " + book.getTitle() + " has been updated."); redirectList(request, response); }
                    catch (ValidationException ex) { showFormErrors(request, response, book, "Edit book", "update", ex, request.getParameter("publishedYear")); }
                }
                case "/delete" -> {
                    Book deleted = bookService.delete(safeId(request.getParameter("bookId")));
                    flash(request, "Book " + deleted.getTitle() + " and its borrowing history have been deleted."); redirectList(request, response);
                }
                default -> response.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
            }
        } catch (ValidationException ex) {
            flash(request, ex.getErrors().getOrDefault("general", ex.getMessage())); redirectList(request, response);
        } catch (DataAccessException ex) {
            if (path.equals("/create") || path.equals("/update")) {
                Book book = bind(request, safeId(request.getParameter("bookId")));
                showFormErrors(request, response, book, path.equals("/create") ? "Add book" : "Edit book", path.substring(1),
                        new ValidationException(Map.of("general", "The book could not be saved. Check the database connection and try again.")), request.getParameter("publishedYear"));
            } else { flash(request, "The book could not be deleted. Please try again."); redirectList(request, response); }
        }
    }

    private void list(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String q = request.getParameter("q");
        try {
            request.setAttribute("books", q == null || q.isBlank() ? bookDao.findAll() : bookDao.search(q.trim()));
        } catch (DataAccessException ex) {
            request.setAttribute("books", java.util.List.of());
            request.setAttribute("pageError", Boolean.TRUE);
        }
        request.setAttribute("searchTerm", q == null ? "" : q.trim());
        consumeFlash(request);
        request.getRequestDispatcher("/WEB-INF/views/books/book-list.jsp").forward(request, response);
    }

    private void showForm(HttpServletRequest request, HttpServletResponse response, Book book, String title, String action, String year) throws ServletException, IOException {
        request.setAttribute("bookForm", book); request.setAttribute("formTitle", title); request.setAttribute("formAction", action);
        request.setAttribute("publishedYearInput", year);
        request.getRequestDispatcher("/WEB-INF/views/books/book-form.jsp").forward(request, response);
    }

    private void showFormErrors(HttpServletRequest request, HttpServletResponse response, Book book, String title, String action, ValidationException ex, String year) throws ServletException, IOException {
        request.setAttribute("bookForm", book); request.setAttribute("formTitle", title); request.setAttribute("formAction", action);
        request.setAttribute("publishedYearInput", year); request.setAttribute("errors", ex.getErrors());
        request.getRequestDispatcher("/WEB-INF/views/books/book-form.jsp").forward(request, response);
    }

    private Book bind(HttpServletRequest request, int id) {
        Book book = new Book(); book.setBookId(id); book.setIsbn(request.getParameter("isbn"));
        book.setTitle(request.getParameter("title")); book.setAuthor(request.getParameter("author"));
        String year = request.getParameter("publishedYear");
        try { book.setPublishedYear(Integer.parseInt(year == null ? "" : year.trim())); }
        catch (NumberFormatException ex) { book.setPublishedYear(0); }
        book.setGenre(request.getParameter("genre")); book.setSynopsis(request.getParameter("synopsis"));
        return book;
    }
    private String path(HttpServletRequest request) { String p = request.getPathInfo(); return p == null || p.isBlank() ? "/" : p; }
    private int parseId(String value) { return Integer.parseInt(value); }
    private int safeId(String value) { try { return parseId(value); } catch (RuntimeException ex) { return 0; } }
    private void redirectList(HttpServletRequest request, HttpServletResponse response) throws IOException { response.sendRedirect(request.getContextPath() + "/librarian/books"); }
    private void flash(HttpServletRequest request, String message) { request.getSession().setAttribute("libisFlash", message); }
    private void consumeFlash(HttpServletRequest request) { Object f = request.getSession().getAttribute("libisFlash"); if (f != null) { request.setAttribute("flashMessage", f); request.getSession().removeAttribute("libisFlash"); } }
}
