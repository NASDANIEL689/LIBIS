package com.example.libicloginflow.service;

import com.example.libicloginflow.dao.BookDao;
import com.example.libicloginflow.dao.LoanDao;
import com.example.libicloginflow.exception.LoanException;
import com.example.libicloginflow.model.Book;

/** All business decisions about borrowing and returning are centralised here. */
public class LoanService {
    public static final int MAX_LOANS = 3;
    private final BookDao bookDao;
    private final LoanDao loanDao;

    public LoanService(BookDao bookDao, LoanDao loanDao) {
        this.bookDao = bookDao;
        this.loanDao = loanDao;
    }

    public void borrow(int memberId, int bookId) throws LoanException {
        Book book = bookDao.findById(bookId);
        if (book == null) throw new LoanException("This book cannot be borrowed because it could not be found.");
        if (loanDao.hasOpenLoan(bookId)) {
            throw new LoanException(book.getTitle() + " cannot be borrowed because it is already on loan.");
        }
        int current = loanDao.countOpenByMember(memberId);
        if (current >= MAX_LOANS) {
            throw new LoanException("You already have " + MAX_LOANS + " books on loan, the maximum allowed. Return a book before borrowing another.");
        }
        loanDao.create(memberId, bookId);
    }

    public void returnBook(int memberId, int bookId) throws LoanException {
        if (!loanDao.markReturned(memberId, bookId)) {
            throw new LoanException("That book is not currently on loan to your account, so it cannot be returned here.");
        }
    }

    public int countOpenByMember(int memberId) { return loanDao.countOpenByMember(memberId); }
}
