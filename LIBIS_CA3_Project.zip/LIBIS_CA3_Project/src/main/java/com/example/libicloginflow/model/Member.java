package com.example.libicloginflow.model;

/** Member entity. Legacy getName()/getLastname() accessors are retained for CA1/CA2 compatibility. */
public class Member {
    private int memberId;
    private String memberNumber;
    private String fullName;
    private String email;
    private String username;
    private String password;
    private String role = "member";

    public Member() { }

    public Member(int memberId, String firstname, String lastname, String email, String password) {
        this.memberId = memberId;
        String first = firstname == null ? "" : firstname.trim();
        String last = lastname == null ? "" : lastname.trim();
        this.fullName = (first + (last.isEmpty() ? "" : " " + last)).trim();
        this.email = email;
        this.username = email;
        this.password = password;
    }

    public int getMemberId() { return memberId; }
    public void setMemberId(int memberId) { this.memberId = memberId; }
    public String getMemberNumber() { return memberNumber; }
    public void setMemberNumber(String memberNumber) { this.memberNumber = memberNumber; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName == null ? null : fullName.trim(); }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public String getName() {
        if (fullName == null || fullName.isBlank()) return "";
        int split = fullName.trim().indexOf(' ');
        return split < 0 ? fullName.trim() : fullName.trim().substring(0, split);
    }
    public void setName(String firstname) {
        String surname = getLastname();
        this.fullName = ((firstname == null ? "" : firstname.trim()) + (surname.isBlank() ? "" : " " + surname)).trim();
    }
    public String getLastname() {
        if (fullName == null) return "";
        String trimmed = fullName.trim();
        int split = trimmed.indexOf(' ');
        return split < 0 ? "" : trimmed.substring(split + 1);
    }
    public void setLastname(String lastname) {
        String first = getName();
        this.fullName = (first + (lastname == null || lastname.isBlank() ? "" : " " + lastname.trim())).trim();
    }
}
