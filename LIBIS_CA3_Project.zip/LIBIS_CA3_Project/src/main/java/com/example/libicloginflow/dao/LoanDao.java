package com.example.libicloginflow.dao;

import com.example.libicloginflow.model.Loan;
import java.util.List;

public interface LoanDao {
    int create(int memberId, int bookId);
    boolean markReturned(int memberId, int bookId);
    int countOpenByMember(int memberId);
    List<Loan> findOpenByMember(int memberId);
    List<Loan> findHistoryByMember(int memberId);
    boolean hasOpenLoan(int bookId);
}
