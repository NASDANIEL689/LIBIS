package com.example.libicloginflow.config;

import com.example.libicloginflow.exception.DataAccessException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/** Looks up the container-managed LIBIS DataSource. */
public final class DataSourceProvider {
    private static final Logger LOGGER = Logger.getLogger(DataSourceProvider.class.getName());
    private static volatile DataSource dataSource;

    private DataSourceProvider() { }

    public static DataSource getDataSource() {
        DataSource current = dataSource;
        if (current == null) {
            synchronized (DataSourceProvider.class) {
                current = dataSource;
                if (current == null) {
                    try {
                        InitialContext context = new InitialContext();
                        current = (DataSource) context.lookup("java:comp/env/jdbc/libis");
                        dataSource = current;
                    } catch (NamingException ex) {
                        LOGGER.log(Level.SEVERE, "Unable to look up the LIBIS JNDI DataSource", ex);
                        throw new DataAccessException("The LIBIS database is temporarily unavailable.", ex);
                    }
                }
            }
        }
        return current;
    }

    public static Connection getConnection() throws SQLException {
        return getDataSource().getConnection();
    }
}
