package com.example.libicloginflow.dao.impl;

import com.example.libicloginflow.config.DataSourceProvider;
import com.example.libicloginflow.dao.MemberDao;
import com.example.libicloginflow.exception.DataAccessException;
import com.example.libicloginflow.model.Member;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MemberDaoJdbc implements MemberDao {
    private static final Logger LOGGER = Logger.getLogger(MemberDaoJdbc.class.getName());
    private static final String SELECT_COLUMNS = "member_id, member_number, full_name, email, username, password, `role`";

    @Override public List<Member> findAll() {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM members ORDER BY member_id";
        try (Connection c = DataSourceProvider.getConnection(); PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            List<Member> result = new ArrayList<>();
            while (rs.next()) result.add(map(rs));
            return result;
        } catch (SQLException ex) { throw failure("Unable to load members", ex); }
    }

    @Override public Member findById(int id) {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM members WHERE member_id = ?";
        try (Connection c = DataSourceProvider.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? map(rs) : null; }
        } catch (SQLException ex) { throw failure("Unable to find member", ex); }
    }

    @Override public Member findByUsername(String username) {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM members WHERE username = ?";
        try (Connection c = DataSourceProvider.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? map(rs) : null; }
        } catch (SQLException ex) { throw failure("Unable to find signed-in member", ex); }
    }

    @Override public Member findByUsernameExact(String username) { return findByUsername(username); }

    @Override public List<Member> search(String term) {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM members WHERE full_name LIKE ? OR member_number LIKE ? ORDER BY full_name";
        String pattern = "%" + (term == null ? "" : term.trim()) + "%";
        try (Connection c = DataSourceProvider.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, pattern); ps.setString(2, pattern);
            try (ResultSet rs = ps.executeQuery()) {
                List<Member> result = new ArrayList<>();
                while (rs.next()) result.add(map(rs));
                return result;
            }
        } catch (SQLException ex) { throw failure("Unable to search members", ex); }
    }

    @Override public Member findByMemberNumber(String memberNumber) {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM members WHERE member_number = ?";
        try (Connection c = DataSourceProvider.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, memberNumber);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? map(rs) : null; }
        } catch (SQLException ex) { throw failure("Unable to check member number", ex); }
    }

    @Override public Member findByEmail(String email) {
        String sql = "SELECT " + SELECT_COLUMNS + " FROM members WHERE email = ?";
        try (Connection c = DataSourceProvider.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? map(rs) : null; }
        } catch (SQLException ex) { throw failure("Unable to check email address", ex); }
    }

    @Override public int create(Member member) {
        String sql = "INSERT INTO members (member_number, full_name, email, username, password, `role`) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection c = DataSourceProvider.getConnection(); PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, member.getMemberNumber()); ps.setString(2, member.getFullName());
            ps.setString(3, member.getEmail()); ps.setString(4, member.getUsername());
            ps.setString(5, member.getPassword()); ps.setString(6, member.getRole());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) { member.setMemberId(keys.getInt(1)); return member.getMemberId(); }
            }
            throw new SQLException("No generated member key was returned.");
        } catch (SQLException ex) { throw failure("Unable to create member", ex); }
    }

    @Override public void update(Member member) {
        String sql = "UPDATE members SET member_number = ?, full_name = ?, email = ?, username = ?, password = ?, `role` = ? WHERE member_id = ?";
        try (Connection c = DataSourceProvider.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, member.getMemberNumber()); ps.setString(2, member.getFullName());
            ps.setString(3, member.getEmail()); ps.setString(4, member.getUsername());
            ps.setString(5, member.getPassword()); ps.setString(6, member.getRole()); ps.setInt(7, member.getMemberId());
            if (ps.executeUpdate() == 0) throw new SQLException("Member was not found for update.");
        } catch (SQLException ex) { throw failure("Unable to update member", ex); }
    }

    @Override public void delete(int id) {
        String sql = "DELETE FROM members WHERE member_id = ?";
        try (Connection c = DataSourceProvider.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            if (ps.executeUpdate() == 0) throw new SQLException("Member was not found for deletion.");
        } catch (SQLException ex) { throw failure("Unable to delete member", ex); }
    }

    private Member map(ResultSet rs) throws SQLException {
        Member member = new Member();
        member.setMemberId(rs.getInt("member_id"));
        member.setMemberNumber(rs.getString("member_number"));
        member.setFullName(rs.getString("full_name"));
        member.setEmail(rs.getString("email"));
        member.setUsername(rs.getString("username"));
        member.setPassword(rs.getString("password"));
        member.setRole(rs.getString("role"));
        return member;
    }

    private DataAccessException failure(String message, SQLException ex) {
        LOGGER.log(Level.SEVERE, message, ex);
        return new DataAccessException(message, ex);
    }
}
