package com.example.libicloginflow.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;

/** Container logout plus session invalidation; all protected responses are non-cacheable. */
public class LogoutController extends HttpServlet {
    @Override protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        logout(request, response);
    }
    @Override protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        logout(request, response);
    }
    private void logout(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try { request.logout(); } catch (ServletException ignored) { /* Session invalidation below is still required. */ }
        HttpSession session = request.getSession(false);
        if (session != null) session.invalidate();
        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.setHeader("Pragma", "no-cache");
        response.setDateHeader("Expires", 0);
        response.sendRedirect(request.getContextPath() + "/login.jsp?logout=1");
    }
}
