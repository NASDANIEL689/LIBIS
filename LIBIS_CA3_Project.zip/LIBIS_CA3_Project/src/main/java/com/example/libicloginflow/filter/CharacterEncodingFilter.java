
package com.example.libicloginflow.filter;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/**
 * Ensures form submissions and Setswana text are decoded as UTF-8.
 * Also prevents browsers from caching sensitive pages.
 */
public class CharacterEncodingFilter implements Filter {

    @Override
    public void doFilter(
            ServletRequest request,
            ServletResponse response,
            FilterChain chain
    ) throws IOException, ServletException {

        // Set character encoding to UTF-8
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");

        // Convert ServletResponse to HttpServletResponse
        HttpServletResponse httpResponse =
                (HttpServletResponse) response;

        // Prevent browser caching
        httpResponse.setHeader(
                "Cache-Control",
                "no-cache, no-store, must-revalidate"
        );

        httpResponse.setHeader("Pragma", "no-cache");
        httpResponse.setDateHeader("Expires", 0);

        // Continue with the filter chain
        chain.doFilter(request, response);
    }
}
