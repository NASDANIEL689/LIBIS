package com.example.libicloginflow.service;

import com.example.libicloginflow.dao.BookDao;
import com.example.libicloginflow.dao.LoanDao;
import com.example.libicloginflow.exception.ValidationException;
import com.example.libicloginflow.model.Book;

import java.time.Year;
import java.util.LinkedHashMap;
import java.util.Map;

/** Book validation, loan-aware deletion, and ISBN duplicate checks. */
public class BookService {
    private final BookDao bookDao;
    private final LoanDao loanDao;

    public BookService(BookDao bookDao, LoanDao loanDao) {
        this.bookDao = bookDao;
        this.loanDao = loanDao;
    }

    public void create(Book book) {
        validate(book);
        bookDao.create(book);
    }

    public void update(Book book) {
        if (bookDao.findById(book.getBookId()) == null) {
            throw new ValidationException(Map.of("general", "The selected book no longer exists."));
        }
        validate(book);
        bookDao.update(book);
    }

    public Book findById(int id) { return bookDao.findById(id); }

    public Book delete(int id) {
        Book book = bookDao.findById(id);
        if (book == null) throw new ValidationException(Map.of("general", "The selected book could not be found."));
        if (loanDao.hasOpenLoan(id)) {
            throw new ValidationException(Map.of("general", book.getTitle() + " cannot be deleted because it is currently on loan."));
        }
        bookDao.delete(id); // ON DELETE CASCADE also clears this book's closed loan history.
        return book;
    }

    private void validate(Book book) {
        Map<String, String> errors = new LinkedHashMap<>();
        if (blank(book.getIsbn())) errors.put("isbn", "ISBN is required.");
        if (blank(book.getTitle())) errors.put("title", "Title is required.");
        if (blank(book.getAuthor())) errors.put("author", "Author is required.");
        if (book.getPublishedYear() < 1) errors.put("publishedYear", "Enter a valid publication year.");
        else if (book.getPublishedYear() > Year.now().getValue()) errors.put("publishedYear", "Publication year cannot be in the future.");
        if (!blank(book.getIsbn())) {
            Book duplicate = bookDao.findByIsbn(book.getIsbn().trim());
            if (duplicate != null && duplicate.getBookId() != book.getBookId()) errors.put("isbn", "That ISBN is already used by another book.");
        }
        if (!errors.isEmpty()) throw new ValidationException(errors);
        book.setIsbn(book.getIsbn().trim()); book.setTitle(book.getTitle().trim()); book.setAuthor(book.getAuthor().trim());
        book.setGenre(book.getGenre() == null ? "" : book.getGenre().trim());
        book.setSynopsis(book.getSynopsis() == null ? "" : book.getSynopsis().trim());
    }

    private boolean blank(String value) { return value == null || value.isBlank(); }
}
