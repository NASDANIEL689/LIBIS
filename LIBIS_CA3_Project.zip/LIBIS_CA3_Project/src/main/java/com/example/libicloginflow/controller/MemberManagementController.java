package com.example.libicloginflow.controller;

import com.example.libicloginflow.dao.MemberDao;
import com.example.libicloginflow.dao.impl.MemberDaoJdbc;
import com.example.libicloginflow.exception.DataAccessException;
import com.example.libicloginflow.exception.ValidationException;
import com.example.libicloginflow.model.Member;
import com.example.libicloginflow.service.MemberService;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.List;
import java.util.Map;

public class MemberManagementController extends HttpServlet {
    private final MemberDao memberDao = new MemberDaoJdbc();
    private final MemberService memberService = new MemberService(memberDao);

    @Override protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String path = path(request);
        try {
            switch (path) {
                case "/new" -> showForm(request, response, new Member(), "Create member", "create");
                case "/edit" -> {
                    Member member = memberService.findById(parseId(request.getParameter("id")));
                    if (member == null) { flash(request, "The selected member could not be found."); redirectList(request, response); return; }
                    showForm(request, response, member, "Edit member", "update");
                }
                case "/delete" -> {
                    Member member = memberService.findById(parseId(request.getParameter("id")));
                    if (member == null) { flash(request, "The selected member could not be found."); redirectList(request, response); return; }
                    request.setAttribute("member", member);
                    request.getRequestDispatcher("/WEB-INF/views/members/member-delete.jsp").forward(request, response);
                }
                default -> list(request, response);
            }
        } catch (DataAccessException ex) {
            flash(request, "Member records could not be loaded. Please check the database connection.");
            redirectList(request, response);
        } catch (IllegalArgumentException ex) {
            flash(request, "The requested member ID is invalid."); redirectList(request, response);
        }
    }

    @Override protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String path = path(request);
        try {
            switch (path) {
                case "/create" -> {
                    Member member = bind(request, 0);
                    try { memberService.create(member); flash(request, "Member " + member.getMemberNumber() + " (" + member.getFullName() + ") has been created."); redirectList(request, response); }
                    catch (ValidationException ex) { showFormErrors(request, response, member, "Create member", "create", ex); }
                }
                case "/update" -> {
                    Member member = bind(request, safeId(request.getParameter("memberId")));
                    try { memberService.update(member); flash(request, "Member " + member.getMemberNumber() + " (" + member.getFullName() + ") has been updated."); redirectList(request, response); }
                    catch (ValidationException ex) { showFormErrors(request, response, member, "Edit member", "update", ex); }
                }
                case "/delete" -> {
                    int id = safeId(request.getParameter("memberId"));
                    Member signedIn = memberDao.findByUsername(request.getRemoteUser());
                    Member deleted = memberService.delete(id, signedIn == null ? -1 : signedIn.getMemberId());
                    flash(request, "Member " + deleted.getMemberNumber() + " (" + deleted.getFullName() + ") and their borrowing history have been deleted.");
                    redirectList(request, response);
                }
                default -> { response.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED); }
            }
        } catch (ValidationException ex) {
            request.getSession().setAttribute("libisFlash", ex.getMessage() + " " + ex.getErrors().getOrDefault("general", ""));
            redirectList(request, response);
        } catch (DataAccessException ex) {
            if (path.equals("/create") || path.equals("/update")) {
                Member member = bind(request, safeId(request.getParameter("memberId")));
                showFormErrors(request, response, member, path.equals("/create") ? "Create member" : "Edit member", path.substring(1),
                        new ValidationException(Map.of("general", "The member could not be saved. Check the database connection and try again.")));
            } else {
                flash(request, "The member could not be deleted. Please try again."); redirectList(request, response);
            }
        }
    }

    private void list(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String q = request.getParameter("q");
        try {
            request.setAttribute("members", q == null || q.isBlank() ? memberDao.findAll() : memberDao.search(q.trim()));
        } catch (DataAccessException ex) {
            request.setAttribute("members", List.of());
            request.setAttribute("pageError", Boolean.TRUE);
        }
        request.setAttribute("searchTerm", q == null ? "" : q.trim());
        consumeFlash(request);
        request.getRequestDispatcher("/WEB-INF/views/members/member-list.jsp").forward(request, response);
    }

    private void showForm(HttpServletRequest request, HttpServletResponse response, Member member, String title, String action) throws ServletException, IOException {
        request.setAttribute("memberForm", member); request.setAttribute("formTitle", title); request.setAttribute("formAction", action);
        request.getRequestDispatcher("/WEB-INF/views/members/member-form.jsp").forward(request, response);
    }

    private void showFormErrors(HttpServletRequest request, HttpServletResponse response, Member member, String title, String action, ValidationException ex) throws ServletException, IOException {
        request.setAttribute("memberForm", member); request.setAttribute("formTitle", title); request.setAttribute("formAction", action);
        request.setAttribute("errors", ex.getErrors());
        request.getRequestDispatcher("/WEB-INF/views/members/member-form.jsp").forward(request, response);
    }

    private Member bind(HttpServletRequest request, int id) {
        Member member = new Member(); member.setMemberId(id);
        member.setMemberNumber(request.getParameter("memberNumber")); member.setFullName(request.getParameter("fullName"));
        member.setEmail(request.getParameter("email")); member.setUsername(request.getParameter("username"));
        member.setPassword(request.getParameter("password")); member.setRole(request.getParameter("role"));
        return member;
    }
    private String path(HttpServletRequest request) { String p = request.getPathInfo(); return p == null || p.isBlank() ? "/" : p; }
    private int parseId(String value) { return Integer.parseInt(value); }
    private int safeId(String value) { try { return parseId(value); } catch (RuntimeException ex) { return 0; } }
    private void redirectList(HttpServletRequest request, HttpServletResponse response) throws IOException { response.sendRedirect(request.getContextPath() + "/librarian/members"); }
    private void flash(HttpServletRequest request, String message) { request.getSession().setAttribute("libisFlash", message); }
    private void consumeFlash(HttpServletRequest request) { Object f = request.getSession().getAttribute("libisFlash"); if (f != null) { request.setAttribute("flashMessage", f); request.getSession().removeAttribute("libisFlash"); } }
}
