package com.example.libicloginflow.controller;

import com.example.libicloginflow.dao.BookDao;
import com.example.libicloginflow.dao.MemberDao;
import com.example.libicloginflow.dao.impl.BookDaoJdbc;
import com.example.libicloginflow.dao.impl.MemberDaoJdbc;
import com.example.libicloginflow.model.Member;
import com.example.libicloginflow.exception.DataAccessException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;

import java.io.IOException;

/** Keeps the CA2 controller responsibility: obtain catalogue data, then forward to a WEB-INF view. */
public class CatalogueController extends HttpServlet {
    private final BookDao bookDao = new BookDaoJdbc();
    private final MemberDao memberDao = new MemberDaoJdbc();

    @Override protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        try {
            String searchTerm = request.getParameter("q");
            request.setAttribute("books", searchTerm == null || searchTerm.isBlank()
                    ? bookDao.findAll() : bookDao.search(searchTerm.trim()));
            request.setAttribute("searchTerm", searchTerm == null ? "" : searchTerm.trim());
            request.setAttribute("totalBooks", ((java.util.List<?>) request.getAttribute("books")).size());
            Member member = memberDao.findByUsername(request.getRemoteUser());
            request.setAttribute("member", member);
            request.setAttribute("isLibrarian", request.isUserInRole("librarian"));
            request.setAttribute("isMember", request.isUserInRole("member"));
            request.getRequestDispatcher("/WEB-INF/views/welcome.jsp").forward(request, response);
        } catch (DataAccessException ex) {
            request.setAttribute("pageError", "The catalogue is temporarily unavailable. Please try again.");
            request.setAttribute("books", java.util.List.of());
            request.setAttribute("searchTerm", request.getParameter("q") == null ? "" : request.getParameter("q"));
            request.setAttribute("totalBooks", 0);
            request.setAttribute("isLibrarian", request.isUserInRole("librarian"));
            request.setAttribute("isMember", request.isUserInRole("member"));
            request.getRequestDispatcher("/WEB-INF/views/welcome.jsp").forward(request, response);
        }
    }
}
