package com.example.libicloginflow.dao.impl;

import com.example.libicloginflow.config.DataSourceProvider;
import com.example.libicloginflow.dao.BookDao;
import com.example.libicloginflow.exception.DataAccessException;
import com.example.libicloginflow.model.Book;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class BookDaoJdbc implements BookDao {
    private static final Logger LOGGER = Logger.getLogger(BookDaoJdbc.class.getName());
    private static final String COLUMNS = "b.book_id, b.isbn, b.title, b.author, b.published_year, b.genre, b.synopsis";
    private static final String AVAILABILITY = "NOT EXISTS (SELECT 1 FROM loans l WHERE l.book_id = b.book_id AND l.returned_on IS NULL)";

    @Override public List<Book> findAll() {
        String sql = "SELECT " + COLUMNS + ", " + AVAILABILITY + " AS available FROM books b ORDER BY b.title";
        try (Connection c = DataSourceProvider.getConnection(); PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            List<Book> result = new ArrayList<>();
            while (rs.next()) result.add(map(rs));
            return result;
        } catch (SQLException ex) { throw failure("Unable to load books", ex); }
    }

    @Override public Book findById(int id) {
        String sql = "SELECT " + COLUMNS + ", " + AVAILABILITY + " AS available FROM books b WHERE b.book_id = ?";
        try (Connection c = DataSourceProvider.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? map(rs) : null; }
        } catch (SQLException ex) { throw failure("Unable to find book", ex); }
    }

    @Override public List<Book> search(String term) {
        String sql = "SELECT " + COLUMNS + ", " + AVAILABILITY + " AS available FROM books b WHERE b.title LIKE ? OR b.author LIKE ? ORDER BY b.title";
        String pattern = "%" + (term == null ? "" : term.trim()) + "%";
        try (Connection c = DataSourceProvider.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, pattern); ps.setString(2, pattern);
            try (ResultSet rs = ps.executeQuery()) {
                List<Book> result = new ArrayList<>();
                while (rs.next()) result.add(map(rs));
                return result;
            }
        } catch (SQLException ex) { throw failure("Unable to search books", ex); }
    }

    @Override public Book findByIsbn(String isbn) {
        String sql = "SELECT " + COLUMNS + ", " + AVAILABILITY + " AS available FROM books b WHERE b.isbn = ?";
        try (Connection c = DataSourceProvider.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, isbn);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? map(rs) : null; }
        } catch (SQLException ex) { throw failure("Unable to check ISBN", ex); }
    }

    @Override public int create(Book book) {
        String sql = "INSERT INTO books (isbn, title, author, published_year, genre, synopsis) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection c = DataSourceProvider.getConnection(); PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bind(ps, book);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) { book.setBookId(keys.getInt(1)); return book.getBookId(); }
            }
            throw new SQLException("No generated book key was returned.");
        } catch (SQLException ex) { throw failure("Unable to create book", ex); }
    }

    @Override public void update(Book book) {
        String sql = "UPDATE books SET isbn = ?, title = ?, author = ?, published_year = ?, genre = ?, synopsis = ? WHERE book_id = ?";
        try (Connection c = DataSourceProvider.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            bind(ps, book); ps.setInt(7, book.getBookId());
            if (ps.executeUpdate() == 0) throw new SQLException("Book was not found for update.");
        } catch (SQLException ex) { throw failure("Unable to update book", ex); }
    }

    @Override public void delete(int id) {
        String sql = "DELETE FROM books WHERE book_id = ?";
        try (Connection c = DataSourceProvider.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            if (ps.executeUpdate() == 0) throw new SQLException("Book was not found for deletion.");
        } catch (SQLException ex) { throw failure("Unable to delete book", ex); }
    }

    private void bind(PreparedStatement ps, Book book) throws SQLException {
        ps.setString(1, book.getIsbn()); ps.setString(2, book.getTitle());
        ps.setString(3, book.getAuthor()); ps.setInt(4, book.getPublishedYear());
        ps.setString(5, book.getGenre()); ps.setString(6, book.getSynopsis());
    }

    private Book map(ResultSet rs) throws SQLException {
        Book book = new Book();
        book.setBookId(rs.getInt("book_id")); book.setIsbn(rs.getString("isbn"));
        book.setTitle(rs.getString("title")); book.setAuthor(rs.getString("author"));
        book.setPublishedYear(rs.getInt("published_year")); book.setGenre(rs.getString("genre"));
        book.setSynopsis(rs.getString("synopsis")); book.setAvailable(rs.getBoolean("available"));
        return book;
    }

    private DataAccessException failure(String message, SQLException ex) {
        LOGGER.log(Level.SEVERE, message, ex);
        return new DataAccessException(message, ex);
    }
}
