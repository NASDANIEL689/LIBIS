package com.example.libicloginflow.dao;

import com.example.libicloginflow.model.Book;
import java.util.List;

public interface BookDao {
    List<Book> findAll();
    Book findById(int id);
    List<Book> search(String term);
    Book findByIsbn(String isbn);
    int create(Book book);
    void update(Book book);
    void delete(int id);
}
