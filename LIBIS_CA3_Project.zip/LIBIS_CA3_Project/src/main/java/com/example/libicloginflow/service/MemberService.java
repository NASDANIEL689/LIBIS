package com.example.libicloginflow.service;

import com.example.libicloginflow.dao.MemberDao;
import com.example.libicloginflow.exception.ValidationException;
import com.example.libicloginflow.model.Member;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Pattern;

/** Member validation and duplicate checks belong here, not in the servlet. */
public class MemberService {
    private static final Pattern EMAIL = Pattern.compile("^[A-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?(?:\\.[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?)+$", Pattern.CASE_INSENSITIVE);
    private final MemberDao memberDao;

    public MemberService(MemberDao memberDao) { this.memberDao = memberDao; }

    public void create(Member member) {
        validate(member, true);
        memberDao.create(member);
    }

    public void update(Member member) {
        Member existing = memberDao.findById(member.getMemberId());
        if (existing == null) {
            throw new ValidationException(Map.of("general", "The selected member no longer exists."));
        }
        if (member.getPassword() == null || member.getPassword().isBlank()) {
            member.setPassword(existing.getPassword());
        }
        validate(member, false);
        memberDao.update(member);
    }

    public Member findById(int id) { return memberDao.findById(id); }

    public Member delete(int id, int signedInMemberId) {
        if (id == signedInMemberId) {
            throw new ValidationException(Map.of("general", "You cannot delete the librarian account you are currently using."));
        }
        Member member = memberDao.findById(id);
        if (member == null) throw new ValidationException(Map.of("general", "The selected member could not be found."));
        memberDao.delete(id); // Database ON DELETE CASCADE removes all loan rows.
        return member;
    }

    private void validate(Member member, boolean creating) {
        Map<String, String> errors = new LinkedHashMap<>();
        if (blank(member.getMemberNumber())) errors.put("memberNumber", "Member number is required.");
        if (blank(member.getFullName())) errors.put("fullName", "Full name is required.");
        if (blank(member.getEmail())) errors.put("email", "Email address is required.");
        else if (!EMAIL.matcher(member.getEmail().trim()).matches()) errors.put("email", "Enter a valid email address.");
        if (blank(member.getUsername())) errors.put("username", "Username is required.");
        if (creating && blank(member.getPassword())) errors.put("password", "Password is required when creating a member.");
        if (!"member".equals(member.getRole()) && !"librarian".equals(member.getRole())) errors.put("role", "Choose a valid account role.");

        if (!blank(member.getMemberNumber())) {
            Member duplicate = memberDao.findByMemberNumber(member.getMemberNumber().trim());
            if (duplicate != null && duplicate.getMemberId() != member.getMemberId()) errors.put("memberNumber", "That member number is already in use.");
        }
        if (!blank(member.getEmail())) {
            Member duplicate = memberDao.findByEmail(member.getEmail().trim());
            if (duplicate != null && duplicate.getMemberId() != member.getMemberId()) errors.put("email", "That email address is already in use.");
        }
        if (!blank(member.getUsername())) {
            Member duplicate = memberDao.findByUsername(member.getUsername().trim());
            if (duplicate != null && duplicate.getMemberId() != member.getMemberId()) errors.put("username", "That username is already in use.");
        }
        if (!errors.isEmpty()) throw new ValidationException(errors);
        member.setMemberNumber(member.getMemberNumber().trim());
        member.setFullName(member.getFullName().trim());
        member.setEmail(member.getEmail().trim());
        member.setUsername(member.getUsername().trim());
    }

    private boolean blank(String value) { return value == null || value.isBlank(); }
}
