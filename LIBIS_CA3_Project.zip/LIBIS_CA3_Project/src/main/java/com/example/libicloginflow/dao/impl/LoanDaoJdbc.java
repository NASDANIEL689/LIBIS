package com.example.libicloginflow.dao.impl;

import com.example.libicloginflow.config.DataSourceProvider;
import com.example.libicloginflow.dao.LoanDao;
import com.example.libicloginflow.exception.DataAccessException;
import com.example.libicloginflow.model.Loan;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LoanDaoJdbc implements LoanDao {
    private static final Logger LOGGER = Logger.getLogger(LoanDaoJdbc.class.getName());
    private static final String LOAN_SELECT = "SELECT l.loan_id, l.member_id, l.book_id, l.borrowed_on, l.returned_on, b.title AS book_title, b.author AS book_author FROM loans l JOIN books b ON b.book_id = l.book_id ";

    @Override public int create(int memberId, int bookId) {
        String sql = "INSERT INTO loans (member_id, book_id, borrowed_on, returned_on) VALUES (?, ?, CURRENT_DATE(), NULL)";
        try (Connection c = DataSourceProvider.getConnection(); PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, memberId); ps.setInt(2, bookId); ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) { return keys.next() ? keys.getInt(1) : 0; }
        } catch (SQLException ex) { throw failure("Unable to record borrowing", ex); }
    }

    @Override public boolean markReturned(int memberId, int bookId) {
        String sql = "UPDATE loans SET returned_on = CURRENT_DATE() WHERE member_id = ? AND book_id = ? AND returned_on IS NULL";
        try (Connection c = DataSourceProvider.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, memberId); ps.setInt(2, bookId);
            return ps.executeUpdate() == 1;
        } catch (SQLException ex) { throw failure("Unable to return book", ex); }
    }

    @Override public int countOpenByMember(int memberId) {
        String sql = "SELECT COUNT(*) FROM loans WHERE member_id = ? AND returned_on IS NULL";
        try (Connection c = DataSourceProvider.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, memberId);
            try (ResultSet rs = ps.executeQuery()) { rs.next(); return rs.getInt(1); }
        } catch (SQLException ex) { throw failure("Unable to count current loans", ex); }
    }

    @Override public List<Loan> findOpenByMember(int memberId) {
        return findForMember(LOAN_SELECT + "WHERE l.member_id = ? AND l.returned_on IS NULL ORDER BY l.borrowed_on DESC, l.loan_id DESC", memberId);
    }

    @Override public List<Loan> findHistoryByMember(int memberId) {
        return findForMember(LOAN_SELECT + "WHERE l.member_id = ? AND l.returned_on IS NOT NULL ORDER BY l.returned_on DESC, l.loan_id DESC", memberId);
    }

    @Override public boolean hasOpenLoan(int bookId) {
        String sql = "SELECT 1 FROM loans WHERE book_id = ? AND returned_on IS NULL LIMIT 1";
        try (Connection c = DataSourceProvider.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, bookId);
            try (ResultSet rs = ps.executeQuery()) { return rs.next(); }
        } catch (SQLException ex) { throw failure("Unable to check book availability", ex); }
    }

    private List<Loan> findForMember(String sql, int memberId) {
        try (Connection c = DataSourceProvider.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, memberId);
            try (ResultSet rs = ps.executeQuery()) {
                List<Loan> result = new ArrayList<>();
                while (rs.next()) result.add(map(rs));
                return result;
            }
        } catch (SQLException ex) { throw failure("Unable to load member loans", ex); }
    }

    private Loan map(ResultSet rs) throws SQLException {
        Loan loan = new Loan();
        loan.setLoanId(rs.getInt("loan_id")); loan.setMemberId(rs.getInt("member_id"));
        loan.setBookId(rs.getInt("book_id"));
        Date borrowed = rs.getDate("borrowed_on");
        Date returned = rs.getDate("returned_on");
        loan.setBorrowedOn(borrowed == null ? null : borrowed.toLocalDate());
        loan.setReturnedOn(returned == null ? null : returned.toLocalDate());
        loan.setBookTitle(rs.getString("book_title")); loan.setBookAuthor(rs.getString("book_author"));
        return loan;
    }

    private DataAccessException failure(String message, SQLException ex) {
        LOGGER.log(Level.SEVERE, message, ex);
        return new DataAccessException(message, ex);
    }
}
