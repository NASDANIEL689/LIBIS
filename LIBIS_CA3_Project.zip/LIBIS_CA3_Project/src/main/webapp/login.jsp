<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>LIBIS | Sign in</title>
<style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;background:linear-gradient(135deg,#edf3ff,#f8fafc);font-family:Inter,Arial,sans-serif;color:#172033}.card{width:min(430px,92vw);padding:38px;background:#fff;border:1px solid #e1e8f2;border-radius:20px;box-shadow:0 22px 60px #18345b15}.brand{font-weight:900;letter-spacing:2px;color:#285fce;font-size:13px}.mark{width:48px;height:48px;border-radius:14px;background:#eaf1ff;color:#285fce;display:grid;place-items:center;font-size:22px;margin:25px 0 15px}.card h1{font-size:29px;margin:0 0 9px}.muted{color:#64748b;line-height:1.6;margin:0 0 25px}.field{margin:17px 0}.field label{display:block;font-size:13px;font-weight:700;margin-bottom:8px}.field input{width:100%;padding:13px 14px;border:1px solid #cbd5e1;border-radius:10px;font-size:15px}.field input:focus{outline:3px solid #dbeafe;border-color:#285fce}button{width:100%;padding:14px;border:0;border-radius:10px;background:#285fce;color:white;font-weight:800;font-size:15px;cursor:pointer;margin-top:10px}.message{padding:12px;border-radius:9px;background:#fff1f2;color:#9f1239;margin:0 0 18px;font-size:13px}.success{padding:12px;border-radius:9px;background:#ecfdf5;color:#047857;margin:0 0 18px;font-size:13px}.hint{font-size:12px;color:#94a3b8;margin-top:24px}
</style>
</head>
<body><main class="card">
<div class="brand">LIBIS · LIBRARY INFORMATION SYSTEM</div><div class="mark">▤</div>
<h1>Welcome back</h1><p class="muted">Sign in with your LIBIS username and password to continue to the library.</p>
<c:if test="${param.logout == '1'}"><p class="success">You have been signed out successfully.</p></c:if>
<form action="${pageContext.request.contextPath}/j_security_check" method="post">
<div class="field"><label for="username">Username</label><input type="text" id="username" name="j_username" autocomplete="username" required></div>
<div class="field"><label for="password">Password</label><input type="password" id="password" name="j_password" autocomplete="current-password" required></div>
<button type="submit">Sign in to LIBIS</button>
</form>
<p class="hint">LIBIS · Your knowledge, one book at a time.</p>
</main></body></html>
