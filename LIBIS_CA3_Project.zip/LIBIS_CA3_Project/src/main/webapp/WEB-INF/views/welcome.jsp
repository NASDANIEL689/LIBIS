<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:if test="${empty sessionScope['jakarta.servlet.jsp.jstl.fmt.locale.session']}"><fmt:setLocale value="en" scope="session"/></c:if>
<c:if test="${param.lang == 'en' or param.lang == 'tn'}"><fmt:setLocale value="${param.lang}" scope="session"/></c:if>
<c:set var="selectedLocale" value="${sessionScope['jakarta.servlet.jsp.jstl.fmt.locale.session']}"/>
<c:choose><c:when test="${selectedLocale.language == 'tn'}"><c:set var="htmlLang" value="tn"/></c:when><c:otherwise><c:set var="htmlLang" value="en"/></c:otherwise></c:choose>
<fmt:setBundle basename="messages" var="msg" scope="page"/>
<fmt:message key="catalogue.searchPlaceholder" bundle="${msg}" var="searchPlaceholder"/>
<fmt:message key="catalogue.searchLabel" bundle="${msg}" var="searchLabel"/>
<!DOCTYPE html>
<html lang="${htmlLang}">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>LIBIS | <fmt:message key="catalogue.title" bundle="${msg}"/></title>
<style>
*{box-sizing:border-box}body{margin:0;background:#f4f7fb;color:#172033;font-family:Inter,Arial,sans-serif}.topbar{background:#fff;border-bottom:1px solid #e2e8f0;padding:17px max(4vw,20px);display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap}.brand{font-weight:900;letter-spacing:2px;color:#285fce;font-size:17px}.top-actions{display:flex;align-items:center;gap:15px;flex-wrap:wrap}.member{color:#64748b;font-size:13px}.nav{display:flex;align-items:center;gap:13px;flex-wrap:wrap}.nav a{font-size:13px;font-weight:700;color:#315b9d;text-decoration:none}.nav a:hover{text-decoration:underline}.logout{color:#b42318!important}.wrap{max-width:1180px;margin:35px auto;padding:0 22px}.intro{display:flex;justify-content:space-between;align-items:end;gap:20px;flex-wrap:wrap}.intro h1{font-size:30px;margin:0 0 8px}.muted{color:#64748b;line-height:1.5}.search{display:flex;gap:8px;flex-wrap:wrap}.search input{width:min(300px,65vw);padding:12px 14px;border:1px solid #cbd5e1;border-radius:9px;background:white}.search button{padding:12px 18px;border:0;border-radius:9px;background:#285fce;color:white;font-weight:700;cursor:pointer}.clear{align-self:center;color:#285fce;text-decoration:none;font-size:13px}.summary{margin:24px 0 12px;color:#64748b;font-size:14px}.table-wrap{overflow-x:auto;background:#fff;border:1px solid #e2e8f0;border-radius:14px;box-shadow:0 8px 25px #18345b0a}table{width:100%;border-collapse:collapse;min-width:760px}th{text-align:left;background:#f8fafc;color:#475569;font-size:11px;text-transform:uppercase;letter-spacing:.7px;padding:16px}td{padding:15px 16px;border-top:1px solid #edf1f6;font-size:14px}tbody tr:hover{background:#fafcff}.pill{display:inline-block;padding:6px 9px;border-radius:20px;font-size:11px;font-weight:800}.yes{background:#dcfce7;color:#166534}.no{background:#fee2e2;color:#991b1b}.action{font-size:12px;color:#285fce;text-decoration:none;border:1px solid #c7d8ff;border-radius:7px;padding:7px 10px;margin:2px;display:inline-block;background:white;font-weight:700;cursor:pointer}.action.primary{background:#285fce;color:#fff;border-color:#285fce}.action:disabled{opacity:.5;cursor:not-allowed}.inline-form{display:inline}.empty{text-align:center;padding:34px;color:#64748b}.alert{padding:13px 16px;background:#fff7ed;color:#9a3412;border:1px solid #fed7aa;border-radius:10px;margin:18px 0}.note{font-size:12px;color:#94a3b8;margin-top:18px}.language{display:inline-flex;gap:6px;align-items:center;padding:5px 8px;border:1px solid #e2e8f0;border-radius:8px}.language a{font-size:12px;text-decoration:none;color:#285fce;font-weight:700}.language .sep{color:#cbd5e1}
@media(max-width:640px){.topbar{align-items:flex-start;flex-direction:column}.top-actions{align-items:flex-start;flex-direction:column}.intro h1{font-size:25px}}
</style>
</head>
<body>
<header class="topbar">
  <div class="brand">LIBIS</div>
  <div class="top-actions">
    <span class="member"><fmt:message key="nav.signedIn" bundle="${msg}"/> <strong><c:out value="${member.fullName}"/></strong></span>
    <nav class="nav">
      <c:if test="${isMember}"><a href="${pageContext.request.contextPath}/loans"><fmt:message key="nav.myLoans" bundle="${msg}"/></a></c:if>
      <c:if test="${isLibrarian}">
        <a href="${pageContext.request.contextPath}/librarian/members"><fmt:message key="nav.members" bundle="${msg}"/></a>
        <a href="${pageContext.request.contextPath}/librarian/books"><fmt:message key="nav.books" bundle="${msg}"/></a>
      </c:if>
      <span class="language"><fmt:message key="nav.language" bundle="${msg}"/> <a href="${pageContext.request.contextPath}/catalogue?lang=en"><fmt:message key="language.english" bundle="${msg}"/></a><span class="sep">|</span><a href="${pageContext.request.contextPath}/catalogue?lang=tn"><fmt:message key="language.setswana" bundle="${msg}"/></a></span>
      <form class="inline-form" method="post" action="${pageContext.request.contextPath}/logout"><button class="action logout" type="submit"><fmt:message key="nav.logout" bundle="${msg}"/></button></form>
    </nav>
  </div>
</header>
<main class="wrap">
<section class="intro">
  <div><h1><fmt:message key="catalogue.heading" bundle="${msg}"/></h1><p class="muted"><fmt:message key="catalogue.subtitle" bundle="${msg}"/></p></div>
  <form class="search" action="${pageContext.request.contextPath}/catalogue" method="get">
    <input type="search" name="q" value="<c:out value='${searchTerm}'/>" placeholder="<c:out value='${searchPlaceholder}'/>" aria-label="<c:out value='${searchLabel}'/>">
    <button type="submit"><fmt:message key="catalogue.searchButton" bundle="${msg}"/></button>
    <c:if test="${not empty searchTerm}"><a class="clear" href="${pageContext.request.contextPath}/catalogue"><fmt:message key="catalogue.clear" bundle="${msg}"/></a></c:if>
  </form>
</section>
<c:if test="${not empty loanError}"><div class="alert" role="alert"><c:out value="${loanError}"/></div></c:if>
<c:if test="${not empty pageError}"><div class="alert" role="alert"><fmt:message key="catalogue.loadError" bundle="${msg}"/></div></c:if>
<p class="summary"><fmt:message key="catalogue.showing" bundle="${msg}"/> <strong><c:out value="${totalBooks}"/></strong> <fmt:message key="catalogue.books" bundle="${msg}"/><c:if test="${not empty searchTerm}"> <fmt:message key="catalogue.matching" bundle="${msg}"/> “<c:out value="${searchTerm}"/>”</c:if>.</p>
<div class="table-wrap"><table><thead><tr>
<th><fmt:message key="table.title" bundle="${msg}"/></th><th><fmt:message key="table.author" bundle="${msg}"/></th><th><fmt:message key="table.genre" bundle="${msg}"/></th><th><fmt:message key="table.availability" bundle="${msg}"/></th><th><fmt:message key="table.actions" bundle="${msg}"/></th>
</tr></thead><tbody>
<c:choose><c:when test="${not empty books}">
<c:forEach var="book" items="${books}">
<tr>
<td><strong><c:out value="${book.title}"/></strong></td><td><c:out value="${book.author}"/></td><td><c:out value="${book.genre}"/></td>
<td><c:choose><c:when test="${book.available}"><span class="pill yes"><fmt:message key="availability.available" bundle="${msg}"/></span></c:when><c:otherwise><span class="pill no"><fmt:message key="availability.onLoan" bundle="${msg}"/></span></c:otherwise></c:choose></td>
<td>
<c:if test="${isMember}"><c:choose><c:when test="${book.available}"><form class="inline-form" method="post" action="${pageContext.request.contextPath}/loans/borrow"><input type="hidden" name="bookId" value="<c:out value='${book.bookId}'/>"/><button class="action primary" type="submit"><fmt:message key="action.borrow" bundle="${msg}"/></button></form></c:when><c:otherwise><span class="action" aria-disabled="true"><fmt:message key="availability.unavailable" bundle="${msg}"/></span></c:otherwise></c:choose></c:if>
<a class="action" href="#reserve" onclick="return false"><fmt:message key="action.reserve" bundle="${msg}"/></a>
</td>
</tr>
</c:forEach>
</c:when><c:otherwise><tr><td colspan="5" class="empty"><fmt:message key="catalogue.noBooks" bundle="${msg}"/></td></tr></c:otherwise></c:choose>
</tbody></table></div>
<p class="note"><fmt:message key="catalogue.reserveNote" bundle="${msg}"/></p>
</main></body></html>
