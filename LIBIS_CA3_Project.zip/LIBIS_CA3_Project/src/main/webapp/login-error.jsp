<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>LIBIS | Login failed</title>
<style>body{font-family:Arial,sans-serif;background:#f4f7fb;color:#172033;min-height:100vh;display:grid;place-items:center;margin:0}.card{background:#fff;padding:36px;border-radius:16px;max-width:460px;width:92%;box-shadow:0 12px 40px #17203312}.error{padding:12px;background:#fff1f2;color:#9f1239;border-radius:8px}a{display:inline-block;margin-top:18px;color:#285fce;font-weight:700;text-decoration:none}</style></head>
<body><main class="card"><h1>Sign-in unsuccessful</h1><p class="error">The username or password was not recognised. Please check your details and try again.</p><a href="login.jsp">Return to sign in</a></main></body></html>
